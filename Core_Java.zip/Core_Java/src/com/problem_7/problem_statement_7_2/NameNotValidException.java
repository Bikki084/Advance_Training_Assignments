package com.problem_7.problem_statement_7_2;

class NameNotValidException extends Exception
{
     public String validname()
     {
          return ("Name is not Valid..Please Re-Enter the Name");
     }
}